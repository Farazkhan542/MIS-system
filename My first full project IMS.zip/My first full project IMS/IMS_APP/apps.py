from django.apps import AppConfig


class ImsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'IMS_APP'
